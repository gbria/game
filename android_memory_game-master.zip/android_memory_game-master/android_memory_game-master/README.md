### Android Memory Metrix Game

### Description
- :rocket: This is application using android native - java for develop a memory matrix game

### How I can run it?
- :rocket: Clone this repository
- :rocket: Run project

### Screenshots

<p>
<img src="https://github.com/hongvinhmobile/android_memory_game/blob/master/screenshots/home_1.jpg?raw=true" width="200"/>
<img src="https://github.com/hongvinhmobile/android_memory_game/blob/master/screenshots/home_2.jpg?raw=true" width="200"/>
</p>

### Author: ***lambiengcode***
